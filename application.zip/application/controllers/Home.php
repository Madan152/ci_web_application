<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// FrontEnd Development
class Home extends CI_Controller {    
    public function index(){
       $this->load->view('front/home');
    }
}
?> 