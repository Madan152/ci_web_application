<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Category extends CI_Controller {
    public function __construct(){
        parent::__construct();
        //.. without login we can't acces category and article controller
        $admin=$this->session->userdata('admin');
        if(empty($admin)){
            $this->session->set_flashdata('msg','Your session has been expired');
            redirect(base_url().'admin/login/index');
        }//..
        $this->load->model('Admin_model');        
        $this->load->model('Category_model');
        $this->load->library('form_validation');
        $this->load->helper('common_helper');// user built helper inside 'helpers' folder
        
    }
    public function index(){
        $queryString=$this->input->get('q');
        $params['queryString']=$queryString;

        $categories=$this->Category_model->getCategories($params);
        $data['categories']=$categories;
        $data['queryString']=$queryString;

        $data['mainModule']='category';// used in header.php for selelected categories
        $data['subModule']='viewCategory';// used in header.php

        $this->load->view('admin/category/list',$data);
    }
    public function create(){      

        $data['mainModule']='category';// used in header.php for selelected categories menu
        $data['subModule']='createCategory';// used in header.php

        // for file uploading
        $config['upload_path']          = './public/uploads/category/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['encrypt_name']        = true;
        
        $this->load->library('upload', $config);
        
        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">','</p>');
        $this->form_validation->set_rules('name','Name','trim|required');  

        // print_r($this->form_validation->run());die;

        if($this->form_validation->run() == true){           
            // echo "<pre>";
            // print_r($_FILES);die;
            if(!empty($_FILES['image_file']['name'])){
                // Now user had selected a file then proceed
                //$this->upload->do_upload('image');// here 'image' is the control name in 'if' condition
                // echo "<pre>";
                //  print_r($_FILES);die;
                if($this->upload->do_upload('image_file')){
                    $data=$this->upload->data();

                    // Resizing Image // this method came from 'common_helper.php'
                    resizeImage($config['upload_path'].$data['file_name'],$config['upload_path'].'thumb/'.$data['file_name'],300,270);
                    // echo "<pre>";
                    // print_r($data);die;
                    // Image uploaded successfully
                        $formArray['name']=$this->input->post('name');
                        $formArray['image']=$data['file_name'];
                        $formArray['status']=$this->input->post('status');
                        $formArray['created_at']=date('Y-m-d H:i:s');
                        $this->Category_model->create($formArray);

                        $this->session->set_flashdata('success','Category added successfully');
                        redirect(base_url().'admin/category/index');
                }else{
                    // We got some problem in image uoloading
                    $error =$this->upload->display_errors('<p class="invalid-feedback">','</p>');
                    
                    $data['errorImageUpload']=$error;// will use in 'create.php'
                    $this->load->view('admin/category/create',$data);
                }
            }else{
               
                // save data into the database without image
                $formArray['name']=$this->input->post('name');
                //$formArray['image']=$this->input->post('image');
                $formArray['status']=$this->input->post('status');
                $formArray['created_at']=date('Y-m-d H:i:s');
                $this->Category_model->create($formArray);

                $this->session->set_flashdata('success','Category added successfully');
                redirect(base_url().'admin/category/index');
            }            
        }else{
            // show errors
            $this->load->view('admin/category/create',$data);
        }
    }
    public function edit($id){
        $category=$this->Category_model->getCategory($id);
        if(empty($category)){
            $this->session->set_flashdata('error','Category not found');
            redirect(base_url().'admin/category/index');
        }
        $this->load->helper('common_helper');// user built helper inside 'helpers' folder

        $data['mainModule']='category';// used in header.php
        $data['subModule']='';// used in header.php 

        // for file uploading
        $config['upload_path']          = './public/uploads/category/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['encrypt_name']        = true;
        
        $this->load->library('upload', $config);
        
        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">','</p>');
        $this->form_validation->set_rules('name','Name','trim|required');        

        if($this->form_validation->run() == true){ 

            if(!empty($_FILES['image_file']['name'])){
                // Now user had selected a file then proceed
                //$this->upload->do_upload('image');// here 'image' is the control name in 'if' condition
                // echo "<pre>";
                //  print_r($_FILES);die;
                if($this->upload->do_upload('image_file')){
                    $data=$this->upload->data();

                    // Resizing Image // this method came from 'common_helper.php'
                    resizeImage($config['upload_path'].$data['file_name'],$config['upload_path'].'thumb/'.$data['file_name'],300,270);
                    
                        $formArray['name']=$this->input->post('name');
                        $formArray['image']=$data['file_name'];
                        $formArray['status']=$this->input->post('status');
                        $formArray['updated_at']=date('Y-m-d H:i:s');
                        $this->Category_model->update($id,$formArray);

                        // check and clear the previous image
                        // unlink() function is used to clear 
                        if(file_exists('./public/uploads/category/'.$category['image'])){
                            unlink('./public/uploads/category/'.$category['image']);
                        }
                        if(file_exists('./public/uploads/category/thumb/'.$category['image'])){
                            unlink('./public/uploads/category/thumb/'.$category['image']);
                        }

                        $this->session->set_flashdata('success','Category updated successfully');
                        redirect(base_url().'admin/category/index');
                }else{
                    // We got some problem in image uoloading
                    $error =$this->upload->display_errors('<p class="invalid-feedback">','</p>');
                    
                    $data['errorImageUpload']=$error;// will use in 'create.php'
                    $data['category']=$category;
                    $this->load->view('admin/category/edit',$data);
                }
            }else{
               
                // save data into the database without image
                $formArray['name']=$this->input->post('name');
                //$formArray['image']=$this->input->post('image');
                $formArray['status']=$this->input->post('status');
                $formArray['updated_at']=date('Y-m-d H:i:s');
                $this->Category_model->update($id,$formArray);

                $this->session->set_flashdata('success','Category updated successfully');
                redirect(base_url().'admin/category/index');
            }  
         }else{
            $data['category']=$category;
            $this->load->view('admin/category/edit',$data);
         }            
     }
    public function delete($id){
        $category=$this->Category_model->getCategory($id);
        if(empty($category)){
            $this->session->set_flashdata('error','Category not found');
            redirect(base_url().'admin/category/index');
        }
        // we have delete image also then
        if(file_exists('./public/uploads/category/'.$category['image'])){
            unlink('./public/uploads/category/'.$category['image']);
        }
        if(file_exists('./public/uploads/category/thumb/'.$category['image'])){
            unlink('./public/uploads/category/thumb/'.$category['image']);
        }
        $this->Category_model->delete($id);
        $this->session->set_flashdata('success','Category Deleted Successfully');
        redirect(base_url().'admin/category/index');
    }
}
?> 