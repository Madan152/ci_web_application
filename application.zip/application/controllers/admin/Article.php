<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Article extends CI_Controller {
    public function __construct(){
        parent::__construct();
        //.. without login we can't acces category and article controller
        $admin=$this->session->userdata('admin');
        if(empty($admin)){
            $this->session->set_flashdata('msg','Your session has been expired');
            redirect(base_url().'admin/login/index');
        }//..
        $this->load->model('Admin_model');        
        $this->load->model('Category_model');
        $this->load->model('Article_model');
        $this->load->helper('common_helper');// for resizeImage() method
        $this->load->library('form_validation');
        $this->load->library('pagination');// for  use pagination into the page
        
    }
    // for listinting the article
    public function index($page=1){
        $queryString=$this->input->get('q');// for search box
        $param['queryString']=$queryString; // for search box      

        // pagination setting
        $config['base_url']=base_url('admin/article/index');
        $config['total_rows']=$this->Article_model->getArticlesCount($param);
        $config['per_page']=3;// show how many page a/c to user
        $config['use_page_numbers']=true;

        // These all are for pagination configuration
        // not working

        $this->pagination->initialize($config);
        $pagination_link=$this->pagination->create_links();

        // for adding limit while fetching the records used for pagination
        $param['offset']=$config['per_page'];
        $param['limit']=($page*$config['per_page'])-$config['per_page'];
        $articles=$this->Article_model->getArticles($param);


        $data['articles']=$articles;// for articles table records
        $data['queryString']=$queryString;// for search box
        $data['pagination_link']=$pagination_link;// for pagination

        $data['mainModule']='article';// used in header.php
        $data['subModule']='viewArticle';// used in header.php 

        $this->load->view("admin/article/list",$data);
        
        
    }
    public function create(){
        $categories=$this->Category_model->getCategories();
        $data['categories']=$categories;

        $data['mainModule']='article';// used in header.php
        $data['subModule']='createArticle';// used in header.php


        // File Upload settings
        $config['upload_path']          = './public/uploads/articles/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['encrypt_name']        = true;
        
        $this->load->library('upload', $config);


        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">','</p>');
        $this->form_validation->set_rules('category_id','Category','trim|required');
        $this->form_validation->set_rules('title','Title','trim|required|min_length[20]');
        $this->form_validation->set_rules('author','Author','trim|required');
        $this->form_validation->set_rules('description','Description','trim|required');


        
        
        if($this->form_validation->run()== true){
            // form validated successfully, you can proceed
            if(!empty($_FILES['image_file']['name'])){
                // here we will save image
                if($this->upload->do_upload('image_file')){
                    $data=$this->upload->data();// here $data stores all information related to image like it's name,size,path etc.
                    
                    // Resize Image and save into public/uploads/thumb_admin and thumb_front folder
                    resizeImage($config['upload_path'].$data['file_name'],$config['upload_path'].'thumb_front/'.$data['file_name'],1120,800);
                    resizeImage($config['upload_path'].$data['file_name'],$config['upload_path'].'thumb_admin/'.$data['file_name'],300,250);
                    
                    // Image uploaded successfully
                        $formArray['title']=$this->input->post('title');
                        $formArray['description']=$this->input->post('description');
                        $formArray['image']=$data['file_name'];                        
                        $formArray['category']=$this->input->post('category_id');
                        $formArray['author']=$this->input->post('author');
                        $formArray['status']=$this->input->post('status');
                        $formArray['created_at']=date('Y-m-d H:i:s');
                        $this->Article_model->addArticle($formArray);

                        $this->session->set_flashdata('success','Article added successfully');
                        redirect(base_url().'admin/article/index');
                }else{
                    // We got some problem in image uoloading
                    $error =$this->upload->display_errors('<p class="invalid-feedback">','</p>');
                    
                    $data['errorImageUpload']=$error;// will use in 'create.php'
                    $this->load->view('admin/article/create',$data);
                }


            }else{
                // save article without image
                $formArray['title']=$this->input->post('title');
                $formArray['description']=$this->input->post('description');
                $formArray['category']=$this->input->post('category_id');
                $formArray['author']=$this->input->post('author');
                $formArray['status']=$this->input->post('status');
                $formArray['created_at']=date('Y-m-d H:i:s');

                $this->Article_model->addArticle($formArray);
                $this->session->set_flashdata('success','Article added successfully');
                redirect(base_url().'admin/article/index');
            }
        }else{
            // form not validated, show errors
            $this->load->view("admin/article/create",$data);
        }

        
    }
    public function edit($id){
        $article=$this->Article_model->getArticle($id);
        
        if(empty($article)){
            $this->session->set_flashdata('error','Article not found');
            redirect(base_url().'admin/article/index');
        }   
        $categories=$this->Category_model->getCategories();
        $data['categories']=$categories;

        $data['mainModule']='article';// used in header.php
        $data['subModule']='';// used in header.php 

        // echo "<pre>";
        // print_r($data);die;

        // for file uploading
        $config['upload_path']          = './public/uploads/articles/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['encrypt_name']        = true;
        
        $this->load->library('upload', $config);
        
        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">','</p>');
        $this->form_validation->set_rules('category','Category','trim|required');
        $this->form_validation->set_rules('title','Title','trim|required|min_length[20]');
        $this->form_validation->set_rules('author','Author','trim|required');
        $this->form_validation->set_rules('description','Description','trim|required');    
       
        if($this->form_validation->run() == true){

            if(!empty($_FILES['image_file']['name'])){
                // Now user had selected a file then proceed
                //$this->upload->do_upload('image');// here 'image' is the control name in 'if' condition
                // echo "<pre>";
                //  print_r($_FILES);die;
                if($this->upload->do_upload('image_file')){
                    $data=$this->upload->data();

                    // Resizing Image // this method came from 'common_helper.php'
                    resizeImage($config['upload_path'].$data['file_name'],$config['upload_path'].'thumb_front/'.$data['file_name'],1120,800);
                    resizeImage($config['upload_path'].$data['file_name'],$config['upload_path'].'thumb_admin/'.$data['file_name'],300,250);
                    
                        $formArray['title']=$this->input->post('title');
                        $formArray['description']=$this->input->post('description');
                        $formArray['image']=$data['file_name'];                        
                        $formArray['category']=$this->input->post('category_id');
                        $formArray['author']=$this->input->post('author');
                        $formArray['status']=$this->input->post('status');
                        $formArray['updated_at']=date('Y-m-d H:i:s');

                        $this->Article_model->updateArticle($id,$formArray);

                        // check and clear the previous image
                        // unlink() function is used to clear 
                        if(file_exists('./public/uploads/articles/'.$article['image'])){
                            unlink('./public/uploads/articles/'.$article['image']);
                        }
                        if(file_exists('./public/uploads/articles/thumb_front/'.$article['image'])){
                            unlink('./public/uploads/articles/thumb_front/'.$article['image']);
                        }
                        if(file_exists('./public/uploads/articles/thumb_admin/'.$article['image'])){
                            unlink('./public/uploads/articles/thumb_admin/'.$article['image']);
                        }

                        $this->session->set_flashdata('success','Article updated successfully');
                        redirect(base_url().'admin/article/index');
                }else{
                    // We got some problem in image uoloading
                    $error =$this->upload->display_errors('<p class="invalid-feedback">','</p>');
                    
                    $data['errorImageUpload']=$error;// will use in 'create.php'
                    $data['article']=$article;
                    $this->load->view('admin/article/edit',$data);
                }
            }else{
               
                // save data into the database without image
                $formArray['title']=$this->input->post('title');
                $formArray['description']=$this->input->post('description');
                $formArray['category']=$this->input->post('category_id');
                $formArray['author']=$this->input->post('author');
                $formArray['status']=$this->input->post('status');
                $formArray['updated_at']=date('Y-m-d H:i:s');

                $this->Article_model->updateArticle($id,$formArray);
                $this->session->set_flashdata('success','Article updated successfully');
                redirect(base_url().'admin/article/index');
            }  
         }else{
            $data['article']=$article;
            $this->load->view('admin/article/edit',$data);
         }            
     }
    public function delete($id){
        $article=$this->Article_model->getArticle($id);
        if(empty($article)){
            $this->session->set_flashdata('error','Article not found');
            redirect(base_url().'admin/article/index');
        }
        // we have delete image also then
        if(file_exists('./public/uploads/articles/'.$article['image'])){
            unlink('./public/uploads/articles/'.$article['image']);
        }
        if(file_exists('./public/uploads/articles/thumb_front/'.$article['image'])){
            unlink('./public/uploads/articles/thumb_front/'.$article['image']);
        }
        if(file_exists('./public/uploads/articles/thumb_admin/'.$article['image'])){
            unlink('./public/uploads/articles/thumb_admin/'.$article['image']);
        }
        $this->Article_model->deleteArticle($id);
        $this->session->set_flashdata('success','Article has been Deleted Successfully');
        redirect(base_url().'admin/article/index');
    }
}
?> 