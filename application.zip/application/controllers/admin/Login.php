<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
        public function __construct(){
        parent::__construct();
        $this->load->model('Admin_model');        
        $this->load->library('form_validation');
        
        }

        public function index(){     
           //echo password_hash('admin',PASSWORD_DEFAULT); // 'admin' is converted in hash form 
           
           // if user loginned
           $admin=$this->session->userdata('admin');
            if(!empty($admin)){
                redirect(base_url().'admin/home/index');
            }
            //
            $this->load->view('admin/login');
        }
        public function authenticate(){           
            $this->form_validation->set_rules('username','Username','trim|required');
            $this->form_validation->set_rules('password','Password','trim|required');
            if($this->form_validation->run()==true){
                // Success
                $username=$this->input->post('username');
                $admin=$this->Admin_model->getByUsername($username);
                // echo "<pre>";
                // print_r($admin);die;
                if(!empty($admin)){
                    $password=$this->input->post('password');
                    // echo "<pre>";
                    // print_r($password);die;
                    if(password_verify($password,$admin['password'])==true){
                        $adminArray['admin_id']=$admin['id'];
                        $adminArray['username']=$admin['username'];
                        $this->session->set_userdata('admin',$adminArray);//'admin' is index here
                        redirect(base_url().'admin/home/index');
                    }else{
                        $this->session->set_flashdata('msg','Either username or password is incorrect');
                        redirect(base_url().'admin/login/index');
                    }
                }else{
                    $this->session->set_flashdata('msg','Either username or password is incorrect');
                    redirect(base_url().'admin/login/index');
                }
            }else{
                // Form Error
                $this->load->view('admin/login');
            }
        }
        public function logout(){
            $this->session->unset_userdata('admin');
            redirect(base_url().'admin/login/index');
        }
}
?> 