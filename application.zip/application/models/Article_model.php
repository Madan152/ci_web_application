<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Article_model extends CI_Model{        
        
        public function getArticle($id){            
            $this->db->where('id',$id);    
            $article=$this->db->get('articles')->row_array();
            return $article;            
        }
        public function getArticles($param=array()){            
            if(isset($param['offset']) && isset($param['limit'])){// limit for pagination
                $this->db->limit($param['offset'],$param['limit']);
            }
            if(!empty($param['queryString'])){// for search box
                $this->db->or_like('title',trim($param['queryString']));// trim() used for eliminating space
                $this->db->or_like('author',trim($param['queryString']));
            }
            $result=$this->db->get('articles')->result_array();
            //echo $this->db->last_query();
            return $result;
        }
        public function getArticlesCount($param=array()){  
            // using these line because, if we search one particular record then paginaton is not apperared on that page because of one page.
            if(!empty($param['queryString'])){// for search box
                $this->db->or_like('title',trim($param['queryString']));// trim() used for eliminating space
                $this->db->or_like('author',trim($param['queryString']));
            }

            $count=$this->db->count_all_results('articles');  
            return $count;        
        }
        public function addArticle($formArray){
            $this->db->insert('articles',$formArray);  
            return $this->db->insert_id(); 
        }
        public function updateArticle($id,$formArray){
            $this->db->where('id',$id);
            $this->db->set($formArray);
            $this->db->update('articles');
        }
        public function deleteArticle($id){
            $this->db->where('id',$id);
            $this->db->delete('articles'); // 'categories' is table name
           
        }
                
    }
?>