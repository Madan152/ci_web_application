<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('public/css/bootstrap.min.css');?>" >
    <link rel="stylesheet" href="<?php echo base_url('public/css/style.css');?>">
    <title>Codeigniter Web Application</title>
  </head>
  <body>
    
<!--For Header Section start-->
  <header class="bg-light">
  <div class="container">
    <nav class="navbar navbar-expand-lg navbar-light pt-3 pb-3">
      <a class="navbar-brand" href="<?php echo base_url();?>">Codeigniter Web Application</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse right-align" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto ">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo base_url();?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">About us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Blog</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Categories</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </nav>
  </div>
</header>
<!--For Header Section end-->

 <!-- For Slide Show i.e Carousel start-->
 <div id="carouselExampleControls" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo base_url('public/images/slide1.jpg');?>" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item ">
      <img src="<?php echo base_url('public/images/slide2.jpg');?>" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item ">
      <img src="<?php echo base_url('public/images/slide3.jpg');?>" class="d-block w-100" alt="">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
  <!-- For Slide Show i.e Carousel end-->

  <!--For About Company start-->
  <div class="container pt-4 pb-4">
    <h3 class="pb-3">About Company</h3>
    <p class="text-muted">Welcome, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <p class="text-muted">The purpose of lorem ipsum is to create a natural looking block of text (sentence, paragraph, page, etc.) that doesn't distract from the layout. A practice not without controversy, laying out pages with meaningless filler text can be very useful when the focus is meant to be on design, not content. </p>
  </div>
  <!--For About Company end-->

  <!--For Our Services start-->
  <div class="bg-light">
    <div class="container pt-4 pb-4">
        <h3 class="pt-3 pb-4">OUR SERVICES</h3>
        <div class="row">
          <div class="col-md-3">
            <div class="card">
              <img src="<?php echo base_url('public/images/box1.jpg');?>" class="card-img-top" alt="">
              <div class="card-body">
                <h5 class="card-title">Website Development</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>                
              </div>
            </div>            
          </div>
          <div class="col-md-3">
            <div class="card">
              <img src="<?php echo base_url('public/images/box2.jpg');?>" class="card-img-top" alt="">
              <div class="card-body">
                <h5 class="card-title">Digital Marketing</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>                
              </div>
            </div>            
          </div>
          <div class="col-md-3">
            <div class="card">
              <img src="<?php echo base_url('public/images/box3.jpg');?>" class="card-img-top" alt="">
              <div class="card-body">
                <h5 class="card-title">Mobile Development</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>                
              </div>
            </div>            
          </div>
          <div class="col-md-3">
            <div class="card">
              <img src="<?php echo base_url('public/images/box4.jpg');?>" class="card-img-top" alt="">
              <div class="card-body">
                <h5 class="card-title">IT Consultancy</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>                
              </div>
            </div>            
          </div>
        </div>
      </div>
  </div>
   <!--For Our Services end-->

    <!--For Latest Blog start-->
  <div class="pb-4 pt-4">
    <div class="container">
        <h3 class="pt-3 pb-4">LATEST BLOGS</h3>
        <div class="row">
          <div class="col-md-3">
            <div class="card">
              <img src="<?php echo base_url('public/images/box1.jpg');?>" class="card-img-top" alt="">
              <div class="card-body">                
                <p class="card-text"><a href="#">Some quick example text to build on the card title and make up the bulk of the card's content.</a></p>                
              </div>
            </div>            
          </div>
          <div class="col-md-3">
            <div class="card">
              <img src="<?php echo base_url('public/images/box2.jpg');?>" class="card-img-top" alt="">
              <div class="card-body">                
                <p class="card-text"><a href="#">Some quick example text to build on the card title and make up the bulk of the card's content.</a></p>                
              </div>
            </div>            
          </div>
          <div class="col-md-3">
            <div class="card">
              <img src="<?php echo base_url('public/images/box3.jpg');?>" class="card-img-top" alt="">
              <div class="card-body">                
                <p class="card-text"><a href="#">Some quick example text to build on the card title and make up the bulk of the card's content.</a></p>                
              </div>
            </div>            
          </div>
          <div class="col-md-3">
            <div class="card">
              <img src="<?php echo base_url('public/images/box4.jpg');?>" class="card-img-top" alt="">
              <div class="card-body">                
                <p class="card-text"><a href="#">Some quick example text to build on the card title and make up the bulk of the card's content.</a></p>                
              </div>
            </div>            
          </div>
        </div>
    </div>
  </div>  
   <!--For Latest Blog end-->

  <!--For Footer Section -->
  <footer class="bg-light pt-5 pb-4 mt-5">
    <div class="container pt-4 pb-4">
      <div class="row">
          <div class="col-md-3">
            <h5>LOGO</h5>
            <small class="text-muted">
              <strong>
                Company Inc.
              </strong><br>12/22- City Center Dhanbad <br>98xxxxxxxx <br> example@example.com
            </small>
          </div> 
          <div class="col-md-3">
            <h5>Important Links</h5>
            <ul class="list-unstyled text-small">
                <li><a href="#" class="text-muted">About Us</a></li>
                <li><a href="#" class="text-muted">Services</a></li>
                <li><a href="#" class="text-muted">Blog</a></li>
                <li><a href="#" class="text-muted">Categories</a></li>
                <li><a href="#" class="text-muted">FAQ</a></li>
            </ul>
          </div>
          <div class="col-md-3">
          <h5>My Accounts</h5>
            <ul class="list-unstyled text-small">
                <li><a href="#" class="text-muted">Login</a></li>
                <li><a href="#" class="text-muted">Register</a></li>
                <li><a href="#" class="text-muted">My Articles</a></li>
            </ul>
          </div>
          <div class="col-md-3">
          <h5>Support</h5>
            <ul class="list-unstyled text-small">
                <li><a href="#" class="text-muted">Contact</a></li>
            </ul>
          </div>
      </div>
    </div> 
  </footer>  
    

    <!-- Bootstrap Bundle with Popper -->
    <script src="<?php echo base_url('public/js/jquery-3.5.1.slim.min.js');?>" ></script>
    <script src="<?php echo base_url('public/js/bootstrap.min.js');?>"></script>   
  </body>
</html>
